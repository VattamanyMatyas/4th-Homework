public class CserelhetoFejuCsavarhuzo extends Csavarhuzo {
    private final int fejMeret;
    private boolean egyhornyuFej = true;
    private boolean phillipsFej = true;
    private boolean imbuszFej = true;
    private Csavarfej csavarfej;

    public CserelhetoFejuCsavarhuzo(int meret, int fejMeret, Csavarfej csavarFej){
        setMeret(meret);
        this.fejMeret = fejMeret;
        this.csavarfej = csavarFej;
    }

    public void fejElhagy(String melyik){
        if(melyik == "egyhornyu"){
            egyhornyuFej = false;
        }
        if(melyik == "phillips"){
            phillipsFej = false;
        }
        if(melyik == "imbusz"){
            imbuszFej = false;
        }
    }
    public boolean fejCsere(String melyikre){

        if(melyikre == null){
            return false;
        }
        
        //

        if(melyikre == "egyhornyu" && this.csavarfej == Csavarfej.EGYHORNYU){
            return false;
        }
        if(melyikre == "phillips" && this.csavarfej == Csavarfej.PHILLIPS){
            return false;
        }
        if(melyikre == "imbusz" && this.csavarfej == Csavarfej.IMBUSZ){
            return false;
        }

        //

        if(melyikre == "egyhornyu" && egyhornyuFej == false){
            return false;
        }
        if(melyikre == "phillips" && phillipsFej == false){
            return false;
        }
        if(melyikre == "imbusz" && imbuszFej == false){
            return false;
        }

        //

        if(this.csavarfej != Csavarfej.EGYHORNYU && melyikre == "egyhornyu" && egyhornyuFej == true){
            super.csavarfej = Csavarfej.EGYHORNYU;
            return true;
        }
        if(this.csavarfej != Csavarfej.PHILLIPS && melyikre == "phillips" && egyhornyuFej == true){
            super.csavarfej = Csavarfej.PHILLIPS;
            return true;
        }
        if(this.csavarfej != Csavarfej.IMBUSZ && melyikre == "imbusz" && egyhornyuFej == true){
            super.csavarfej = Csavarfej.IMBUSZ;
            return true;
        }

        return false;
    }

    @Override
    public int getMeret() {
        return super.getMeret() - this.fejMeret; //ha van egy osztályod és egy alosztályod, akkor a super előtaggal hívod meg a főosztály methodját.
    }
}