public class Csavarhuzo{
    private int meret;
    protected Csavarfej csavarfej;

    public Csavarhuzo(int meret, Csavarfej fej){
        this.meret = meret;
        this.csavarfej = fej;
    }
    public Csavarhuzo(){ //implicit superconstructor is undefined HIBA elkerülésére

    }
    public int getMeret() {
        return meret;
    }
    public void setMeret(int ujMeret) {
        this.meret = ujMeret;
    }

    public Csavarfej getCsavarfej(){
        return csavarfej;
    }
    
    @Override
    public String toString() {
        if(getCsavarfej() == Csavarfej.EGYHORNYU){
            return "hagyomanyos feju csavarhuzo";
        }
        else if(getCsavarfej() == Csavarfej.PHILLIPS){
            return "csillagfeju csavarhuzo";
        }
        else{
            return "imbuszfeju csavarhuzo";
        }
    }
    
}